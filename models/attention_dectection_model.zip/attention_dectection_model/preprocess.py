import numpy as np
def preprocess(input):
    return np.array()