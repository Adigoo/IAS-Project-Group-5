
def post_processing( output_data ):
    if( output_data == True ):
        return 1

    elif( output_data == False ):
        return 0